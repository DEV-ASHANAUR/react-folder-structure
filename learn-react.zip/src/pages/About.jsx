import Button from "../components/Button"

const About = () => {
  return (
    <div><Button link="/">Home</Button></div>
  )
}

export default About