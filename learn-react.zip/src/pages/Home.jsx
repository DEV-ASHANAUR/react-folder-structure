import Button from "../components/Button"

const Home = () => {
  return (
    <div>
        <Button link="/about">About</Button>
    </div>
  )
}

export default Home